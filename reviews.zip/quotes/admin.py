from django.contrib import admin
from . models import QuoteRequest
# Register your models here.

admin.site.register(QuoteRequest)