from django.contrib import admin
from payments.models import PaymentProvider

# Register your models here.

admin.site.register(PaymentProvider)