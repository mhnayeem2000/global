from django.contrib import admin
from .models import Review , FAQ
# Register your models here.


admin.site.register(Review)
admin.site.register(FAQ)