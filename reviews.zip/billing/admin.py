from django.contrib import admin
from billing.models import Milestone


admin.site.register(Milestone)
