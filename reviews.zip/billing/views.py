from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.conf import settings
import requests
from decimal import Decimal
from .models import Milestone
from .serializers import MilestoneSerializer
from users.permissions import IsEmployeeOrOwner
from ecommerce.models import Transaction, Order
from payments.models import PaymentProvider

class MilestoneViewSet(viewsets.ModelViewSet):

    serializer_class = MilestoneSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
 
        user = self.request.user
        if user.role in [user.Role.EMPLOYEE, user.Role.OWNER]:
            return Milestone.objects.all()
        return Milestone.objects.filter(order__user=user)

    def get_permissions(self):

        if self.action in ['list', 'retrieve', 'initiate_payment']:
            return [IsAuthenticated()]
        return [IsEmployeeOrOwner()]

    def create(self, request, *args, **kwargs):

        response = super().create(request, *args, **kwargs)
        if response.status_code == status.HTTP_201_CREATED:
            order_id = response.data.get('order')
            try:
                order = Order.objects.get(id=order_id)
                if order.status in [Order.Status.ACTIVE, Order.Status.PAID]:
                    order.status = Order.Status.AWAITING_PAYMENT
                    order.save()
            except Order.DoesNotExist:
                pass
        return response

    @action(detail=True, methods=['post'])
    def initiate_payment(self, request, pk=None):

        milestone = self.get_object()

        # Security & Business Logic Checks
        if milestone.order.user != request.user and request.user.role == 'CUSTOMER':
            return Response({"error": "You do not have permission to pay for this milestone."}, status=status.HTTP_403_FORBIDDEN)
        
        if milestone.status == Milestone.Status.PAID:
            return Response({"error": "This milestone has already been paid."}, status=status.HTTP_400_BAD_REQUEST)

        # 1. Get the chosen provider code from the frontend request
        provider_code = request.data.get('provider_code')
        if not provider_code:
            return Response({"error": "A 'provider_code' must be selected to proceed with payment."}, status=status.HTTP_400_BAD_REQUEST)

        # 2. Fetch the rules for this provider from our database
        try:
            provider = PaymentProvider.objects.get(provider_name_code=provider_code, is_active=True)
        except PaymentProvider.DoesNotExist:
            return Response({"error": "The selected payment provider is not valid or is currently disabled."}, status=status.HTTP_404_NOT_FOUND)

        # --- ENFORCE BUSINESS RULES ---
        
        milestone_amount = milestone.amount

        if milestone_amount < provider.min_amount:
            return Response({"error": f"Payment amount of ${milestone_amount} is below the minimum of ${provider.min_amount} for this provider."}, status=status.HTTP_400_BAD_REQUEST)
        if milestone_amount > provider.max_amount:
            return Response({"error": f"Payment amount of ${milestone_amount} exceeds the maximum of ${provider.max_amount} for this provider."}, status=status.HTTP_400_BAD_REQUEST)

        fee_percentage = provider.processing_fee_percentage / Decimal('100')
        processing_fee = milestone_amount * fee_percentage
        final_charge_amount = milestone_amount + processing_fee
        

        transaction = Transaction.objects.create(
            order=milestone.order,
            milestone=milestone,
            amount=final_charge_amount, # Use the final amount including the fee
            status=Transaction.Status.PENDING,
            provider_name=provider.title 
        )

        callback_url_with_id = f"{settings.RISKPAY_CALLBACK_URL}?transaction_id={transaction.id}"
        params = {'address': settings.RISKPAY_MERCHANT_WALLET_ADDRESS, 'callback': callback_url_with_id}
        
        try:
            response = requests.get(settings.RISKPAY_API_WALLET_URL, params=params)
            response.raise_for_status() 
            riskpay_data = response.json()
        except requests.exceptions.RequestException as e:
            transaction.status = Transaction.Status.FAILED
            transaction.save()
            return Response({"error": f"Could not connect to the payment gateway: {str(e)}"}, status=status.HTTP_503_SERVICE_UNAVAILABLE)
        except ValueError: 
             transaction.status = Transaction.Status.FAILED
             transaction.save()
             return Response({"error": "Received an invalid response from the payment gateway."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        transaction.gateway_address_in = riskpay_data.get('address_in')
        transaction.gateway_polygon_address_in = riskpay_data.get('polygon_address_in')
        transaction.gateway_ipn_token = riskpay_data.get('ipn_token')
        transaction.save()

        payment_url_params = {
            'address': transaction.gateway_address_in,
            'amount': final_charge_amount, # Send the FINAL amount to RiskPay
            'provider': provider.provider_name_code,
            'email': request.user.email,
            'currency': 'USD'
        }
        
        prepared_request = requests.Request('GET', settings.RISKPAY_PAYMENT_PROCESSING_URL, params=payment_url_params)
        payment_url = prepared_request.prepare().url
        
        return Response({
            'payment_url': payment_url, 
            'milestone_amount': milestone_amount,
            'processing_fee': processing_fee,
            'final_charge_amount': final_charge_amount
        }, status=status.HTTP_200_OK)