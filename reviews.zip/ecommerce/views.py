from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import Order, Transaction
from .serializers import OrderListSerializer, OrderDetailSerializer, TransactionSerializer
from users.permissions import IsEmployeeOrOwner
from billing.models import Milestone 

class OrderViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]


    def get_queryset(self):
        user = self.request.user
        if user.role in [user.Role.EMPLOYEE, user.Role.OWNER]:
            return Order.objects.all().order_by("-created_at")
        return Order.objects.filter(user=user).order_by("-created_at")

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return OrderDetailSerializer
        return OrderListSerializer

    def perform_create(self, serializer):
        order = serializer.save(user=self.request.user)
        plan = order.plan
        
        if plan:
            Milestone.objects.create(
                order=order,
                title=f"Initial payment for {plan.name}",
                amount=plan.price,
                status=Milestone.Status.PENDING
            )

    @action(detail=True, methods=["patch"], permission_classes=[IsEmployeeOrOwner])
    def update_status(self, request, pk=None):
        order = self.get_object()
        new_status = request.data.get("status")
        valid_statuses = [choice[0] for choice in Order.Status.choices]
        if new_status not in valid_statuses:
            return Response({"error": "Invalid status."}, status=status.HTTP_400_BAD_REQUEST)
        order.status = new_status
        order.save()
        return Response({"message": f"Order status updated to {order.status}"}, status=status.HTTP_200_OK)


class TransactionViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = TransactionSerializer
    permission_classes = [IsAuthenticated]
    def get_queryset(self):
        user = self.request.user
        if user.role in [user.Role.EMPLOYEE, user.Role.OWNER]:
            return Transaction.objects.all().order_by('-timestamp')
        return Transaction.objects.filter(order__user=user).order_by('-timestamp')