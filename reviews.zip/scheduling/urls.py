from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import EmployeeAvailabilityViewSet, AppointmentViewSet, SchedulingView

router = DefaultRouter()
router.register(r'availabilities', EmployeeAvailabilityViewSet, basename='employee-availability')
router.register(r'appointments', AppointmentViewSet, basename='appointment')

urlpatterns = [
    path('', include(router.urls)),
    path('available-slots/', SchedulingView.as_view(), name='available-slots'),
]