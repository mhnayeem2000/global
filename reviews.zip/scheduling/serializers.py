from rest_framework import serializers
from .models import EmployeeAvailability, Appointment
from users.serializers import UserSerializer

class EmployeeAvailabilitySerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployeeAvailability
        fields = ['id', 'employee', 'weekday', 'start_time', 'end_time']
        read_only_fields = ['employee']


class AppointmentSerializer(serializers.ModelSerializer):
    customer = UserSerializer(read_only=True)
    employee = UserSerializer(read_only=True)

    employee_id = serializers.IntegerField(write_only=True)

    class Meta:
        model = Appointment
        fields = ['id', 'customer', 'employee', 'employee_id', 'start_time', 'end_time', 'notes']
        read_only_fields = ['customer']

class AppointmentSerializer(serializers.ModelSerializer):
    customer = UserSerializer(read_only=True)
    employee = UserSerializer(read_only=True)
    employee_id = serializers.IntegerField(write_only=True)

    class Meta:
        model = Appointment
        fields = [
            'id', 'customer', 'employee', 'employee_id', 'start_time', 'end_time', 
            'notes', 'status', 'meeting_link' 
        ]
        read_only_fields = ['customer', 'status', 'meeting_link'] 
